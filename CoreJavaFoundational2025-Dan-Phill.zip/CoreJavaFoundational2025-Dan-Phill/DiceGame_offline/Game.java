public class Game {
    public static void main(String[] args) {
        Dice dice = new Dice();

        Player player1 = new Player("Player 1");
        Player player2 = new Player("Player 2");

        System.out.println("🎲 Dice Game Start!\n");

        player1.takeTurn(dice);
        player2.takeTurn(dice);

        // Decide winner
        if (player1.score > player2.score) {
            System.out.println("🏆 " + player1.name + " wins!");
        } else if (player2.score > player1.score) {
            System.out.println("🏆 " + player2.name + " wins!");
        } else {
            System.out.println("🤝 It's a tie!");
        }
    }
}
