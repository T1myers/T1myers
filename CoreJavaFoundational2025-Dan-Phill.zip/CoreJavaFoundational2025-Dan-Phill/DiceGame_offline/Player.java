public class Player {
    String name;
    int score = 0;

    public Player(String name) {
        this.name = name;
    }

    public void takeTurn(Dice dice) {
        for (int i = 1; i <= 6; i++) {
            int roll = dice.roll();
            System.out.println(name + " rolled: " + roll);
            score += roll;
        }
        System.out.println(name + "'s total score: " + score + "\n");
    }
}
