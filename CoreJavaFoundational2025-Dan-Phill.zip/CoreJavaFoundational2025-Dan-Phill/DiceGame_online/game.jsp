<%@ page import="java.util.Random" %>
<%
    Integer playerNumber = (Integer) session.getAttribute("playerNumber");
    String username = (String) session.getAttribute("username");

    if (application.getAttribute("loop") == null) {
        application.setAttribute("loop", 0); 
    }

    if (application.getAttribute("currentTurn") == null) {
        application.setAttribute("currentTurn", 1); 
    }

    if (application.getAttribute("p1_score") == null) {
        application.setAttribute("p1_score", 0);
    }
    if (application.getAttribute("p2_score") == null) {
        application.setAttribute("p2_score", 0);
    }

    int loop = (Integer) application.getAttribute("loop");
    int currentTurn = (Integer) application.getAttribute("currentTurn");
    int p1_score = (Integer) application.getAttribute("p1_score");
    int p2_score = (Integer) application.getAttribute("p2_score");

    String diceMessage = "";

    if (loop > 12) {
        response.sendRedirect("winner.jsp");
    }

    if ("roll".equals(request.getParameter("action")) && playerNumber == currentTurn) {
        loop += 1;
        application.setAttribute("loop", loop);
        Random rand = new Random();
        int dice = rand.nextInt(6) + 1;
        diceMessage = "You rolled a " + dice + "!";

        if (playerNumber == 1) {
            application.setAttribute("p1_score", p1_score + dice);
            application.setAttribute("currentTurn", 2);
        } else {
            application.setAttribute("p2_score", p2_score + dice);
            application.setAttribute("currentTurn", 1);
        }
        response.sendRedirect("game.jsp");
    }
%>

<!DOCTYPE html>
<html>
<head>
    <title>Dice Game</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(to right, #e0f7fa, #80deea);
            text-align: center;
            padding: 40px;
            color: #333;
        }

        h1 {
            font-size: 32px;
            color: #00796b;
        }

        h2 {
            color: #004d40;
        }

        p {
            font-size: 20px;
        }

        form {
            margin: 20px;
        }

        input[type="submit"] {
            padding: 10px 20px;
            font-size: 18px;
            background-color: #00796b;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #004d40;
        }

        .scoreboard {
            margin: 30px auto;
            width: 300px;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 2px 2px 10px rgba(0,0,0,0.1);
        }

        .message {
            font-size: 24px;
            margin: 20px 0;
            color: #00695c;
        }

        .wait {
            color: #d32f2f;
            font-size: 20px;
        }
    </style>
</head>
<body>

    <h1>Welcome Player <%= playerNumber %> (<%= username %>)</h1>

    <div class="scoreboard">
        <h2>Scores:</h2>
        <p>Player 1: <%= application.getAttribute("p1_score") %></p>
        <p>Player 2: <%= application.getAttribute("p2_score") %></p>
    </div>

    <% if (playerNumber != currentTurn) { %>
        <script>
            setInterval(() => {
                location.reload();
            }, 2000);
        </script>
    <% } %>

    <% if (!diceMessage.isEmpty()) { %>
        <div class="message"><%= diceMessage %></div>
    <% } %>

    <% if (playerNumber == currentTurn) { %>
        <h2>It's your turn!</h2>
        <form method="post" action="game.jsp">
            <input type="hidden" name="action" value="roll">
            <input type="submit" value="Roll Dice">
        </form>
    <% } else { %>
        <p class="wait">Please wait for Player <%= currentTurn %> to roll.</p>
    <% } %>

    <form action="server_reset.jsp" method="post">
        <input type="submit" value="Reset Game">
    </form>

</body>
</html>
