<%@ page import="javax.servlet.*" %>
<%
String user = request.getParameter("username");

if (user == null || user.trim().equals("")) {
    out.println("Username is required.");
    return;
}

session.setAttribute("username", user); 

synchronized (application) {
    Integer playerCount = (Integer) application.getAttribute("playerCount");

    if (playerCount == null) playerCount = 0;

    if (playerCount == 0) {
        application.setAttribute("player1", user);
        application.setAttribute("playerCount", 1);
        session.setAttribute("playerNumber", 1);
    } else if (playerCount == 1) {
        application.setAttribute("player2", user);
        application.setAttribute("playerCount", 2);
        session.setAttribute("playerNumber", 2);
    } else {
        out.println("<h2>Game already has 2 players.</h2>");
        return;
    }
}
%>

<!DOCTYPE html>
<html>
<head>
    <title>Player Ready</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(to right, #c8e6c9, #a5d6a7);
            text-align: center;
            padding: 60px;
            color: #1b5e20;
        }

        h1 {
            font-size: 36px;
            margin-bottom: 20px;
        }

        form {
            margin: 20px;
        }

        input[type="submit"] {
            padding: 12px 28px;
            font-size: 18px;
            background-color: #2e7d32;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #1b5e20;
        }

        .card {
            background-color: #e8f5e9;
            margin: auto;
            width: 50%;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0px 4px 10px rgba(0,0,0,0.2);
        }
    </style>
</head>
<body>
    <div class="card">
        <h1>You are Player <%= session.getAttribute("playerNumber") %>: <%= session.getAttribute("username") %></h1>
        <h1> Press continue when ready</h1>

        <form action="game.jsp" method="post">
            <input type="submit" value=" Continue">
        </form>

        <form action="server_reset.jsp" method="post">
            <input type="submit" value=" Reset Player Count">
        </form>
    </div>
</body>
</html>
