<%
application.removeAttribute("playerCount");
application.removeAttribute("player1");
application.removeAttribute("player2");
application.removeAttribute("p1_score");
application.removeAttribute("p2_score");
application.setAttribute("loop", 0);
session.invalidate();  // optional: reset current session too

response.sendRedirect("home.html");
%>

