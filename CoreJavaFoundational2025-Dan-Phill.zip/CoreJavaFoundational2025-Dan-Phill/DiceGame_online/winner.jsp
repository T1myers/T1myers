<%
    int score1 = (Integer) application.getAttribute("p1_score");
    int score2 = (Integer) application.getAttribute("p2_score");
    String ply1 = (String) application.getAttribute("player1");
    String ply2 = (String) application.getAttribute("player2");
    String winner;

    if (score1 > score2) {
        winner = ply1;
    } else if (score2 > score1) {
        winner = ply2;
    } else {
        winner = "It's a tie!";
    }
%>

<!DOCTYPE html>
<html>
<head>
    <title>Winner</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(to right, #ffe082, #ffcc80);
            text-align: center;
            padding: 50px;
            color: #3e2723;
        }

        h1 {
            font-size: 42px;
            margin-bottom: 20px;
            color: #bf360c;
        }

        h2 {
            font-size: 32px;
            margin-top: 30px;
            color: #d84315;
        }

        p {
            font-size: 24px;
            margin: 10px 0;
        }

        .scoreboard {
            background-color: #fff3e0;
            padding: 30px;
            margin: 30px auto;
            width: 400px;
            border-radius: 12px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }

        form {
            display: inline-block;
            margin: 15px;
        }

        input[type="submit"] {
            padding: 12px 24px;
            font-size: 18px;
            background-color: #ff6f00;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #e65100;
        }
    </style>
</head>
<body>
    <h1> Game Over </h1>

    <div class="scoreboard">
        <p> <strong><%= ply1 %></strong> Score: <%= score1 %></p>
        <p> <strong><%= ply2 %></strong> Score: <%= score2 %></p>

        <h2> Winner: <%= winner %></h2>
    </div>

    <form action="server_reset.jsp" method="post">
        <input type="submit" value=" Play Again">
    </form>
    <form action="server_reset.jsp" method="post">
        <input type="submit" value=" Reset Server">
    </form>
</body>
</html>
